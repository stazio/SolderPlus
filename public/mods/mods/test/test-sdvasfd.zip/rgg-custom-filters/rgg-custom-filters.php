<?php
/*
Plugin Name: RGG Custom Filters
Plugin URI: http://staz.io/rgg-custom-filters
Description: Overwrites the RGG default shortcode with one that links to custom filters. Last version it worked with was 2.0.5.
Author: Staz Modrzynski
Version: 1.0.0
*/
function staz_rgg_gallery_shortcode($output, $attr) {
		global $all_settings, $rgg_options;

		$post = get_post();

		// image_size is deprecated, but if it is set and size is empty => size = image_size.
		if (!empty($attr['image_size']) && empty($attr['size'])) {
			$attr['size'] = $attr['image_size'];
		}

		// create settings based on the attributes set in the shortcode.
		$settings_arr = shortcode_atts(array(
	        'type' => $rgg_options['type'],
	        'class' => $rgg_options['class'],
	        'rel' => $rgg_options['rel'],
	        'ids' => $rgg_options['ids'],
	        'margin' => intval($rgg_options['margin']),
	        'scale' => doubleval($rgg_options['scale']),
	        'maxrowheight' => intval($rgg_options['maxrowheight']),
	        'intime' => intval($rgg_options['intime']),
	        'outtime' => intval($rgg_options['outtime']),
	        'captions' => $rgg_options['captions'],

			// default params  that can be inherited from gallery_shortcode
			'order'      => 'ASC',
			'orderby'    => $rgg_options['orderby'],
			'id'         => $rgg_options['id'] == '' ? $post->ID : $rgg_options['id'],
			'size'       => $rgg_options['size'], // default changed from thumbnail to medium, because that makes more sense
			'include'    => $rgg_options['include'],
			'exclude'    => $rgg_options['exclude']
	    ), $attr);

		extract($settings_arr);

		if ($type == 'native') {
			// returning nothing will make gallery_shortcode take over
			return '';
		}

		/* code below is based on default gallery_shortcode (wp-includes/media.php) */
		/* BEGIN ------------------- */

		static $instance = 0;
		$instance++;

		if ( ! empty( $ids ) ) {
			// 'ids' is explicitly ordered, unless you specify otherwise.
			if ( empty( $orderby ) ) $orderby = 'post__in';
			$include = $ids;
		}

		// Allow plugins/themes to override the default gallery template. // NOT NEEDED ofcourse
		// $output = apply_filters('post_gallery', '', $attr);
		// if ( $output != '' ) return $output;

		// We're trusting author input, so let's at least make sure it looks like a valid orderby statement
		$orderby = sanitize_sql_orderby( $orderby );
		if ( !$orderby ) unset( $orderby );

		$id = intval($id);
		if ( 'RAND' == $order )
			$orderby = 'none';

		if ( !empty($include) ) {
			$_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

			$attachments = array();
			foreach ( $_attachments as $key => $val ) {
				$attachments[$val->ID] = $_attachments[$key];
			}
		} elseif ( !empty($exclude) ) {
			$attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
		} else {
			$attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
		}

		if ( empty($attachments) )
			return '';

		if ( is_feed() ) {
			$output = "\n";
			foreach ( $attachments as $att_id => $attachment )
				$output .= wp_get_attachment_link($att_id, $size, true) . "\n";
			return $output;
		}

		/* ------------------------- END */



		$all_settings[] = $settings_arr;

		ob_start();
	?>
			<div class="rgg-imagegrid <?php echo $class ?>" rgg_id="<?php echo count($all_settings) ?>">

	<?php
		foreach ( $attachments as $mid => $attachment ) {
			$info = wp_get_attachment_image_src( $mid, 'large' );
			$link = $info[0];
			$title = get_post_field('post_excerpt', $mid);
			$title_esc = htmlentities($title, ENT_COMPAT, 'UTF-8');

                        // Photography Fields. This code was done by Staz.
                        if ($photo_type = get_field('photo_type', $mid)) {
                            $photo_type = is_array($photo_type) ? $photo_type[0] : $photo_type;
                               $link = home_url('/' . $photo_type);
                        } 

			$a_title = $captions == 'title' ? "title=\"$title_esc\"" : '';
			$img = wp_get_attachment_image($mid, $size);
			echo "<a class=\"rgg-a\" rel=\"$rel\" href=\"$link\" $a_title>";
			echo $img;
			if ($captions == 'overlay' && !empty($title_esc)) {
				echo '<span class="rgg-caption"><span class="rgg-inner-caption">'.$title_esc.'</span></span>';
			}
			echo "</a>";
			// echo wp_get_attachment_link($mid, 'medium', true);
			// echo $link;
		}
	?>
			</div>
			<div style="clear:both"></div>
	<?php
		//possible solution to get rid of p-tags.
		//remove_filter( 'the_content', 'wpautop' );
		//add_filter( 'the_content', 'wpautop' , 12);
		// return ob_get_clean();

		// better solution to get rid of p-tags: [raw][/raw] : removed again, seemed to mess things up in some wordpress sites.
		return do_shortcode(ob_get_clean());
	}
if (function_exists('rgg_gallery_shortcode')) 
    remove_filter('post-gallery', 'rgg_gallery_shortcode');

    add_filter( 'post_gallery', 'staz_rgg_gallery_shortcode', 11, 2 );
 ?>
